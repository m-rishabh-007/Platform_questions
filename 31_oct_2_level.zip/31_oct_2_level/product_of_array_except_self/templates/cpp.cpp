class Solution {
public:
    vector<int> productExceptSelf(vector<int>& nums);
};
