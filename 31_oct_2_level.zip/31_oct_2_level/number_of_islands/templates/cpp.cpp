class Solution {
public:
    int numIslands(vector<vector<char>>& grid);
};
