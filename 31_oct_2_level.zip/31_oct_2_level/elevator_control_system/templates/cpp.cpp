class Solution {
public:
    vector<string> simulateElevatorSystem(int numFloors, int numElevators, 
                                          vector<string>& requests);
};
