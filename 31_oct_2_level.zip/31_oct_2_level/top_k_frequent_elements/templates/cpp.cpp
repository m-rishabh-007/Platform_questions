class Solution {
public:
    vector<int> topKFrequent(vector<int>& nums, int k);
};
