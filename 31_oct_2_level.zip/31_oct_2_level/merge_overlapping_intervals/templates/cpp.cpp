class Solution {
public:
    vector<vector<int>> merge(vector<vector<int>>& intervals);
};
